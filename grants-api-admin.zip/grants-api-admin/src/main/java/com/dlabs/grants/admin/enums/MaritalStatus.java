package com.dlabs.grants.admin.enums;

public enum MaritalStatus {

	SINGLE, MARRIED, DIVORCED, WIDOW, SEPARATED
}