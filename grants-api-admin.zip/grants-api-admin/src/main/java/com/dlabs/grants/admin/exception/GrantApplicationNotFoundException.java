package com.dlabs.grants.admin.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class GrantApplicationNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -8473013970879947823L;

	public GrantApplicationNotFoundException(String message) {
		super(message);
	}
}