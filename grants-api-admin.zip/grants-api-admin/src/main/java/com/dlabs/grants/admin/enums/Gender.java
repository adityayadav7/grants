package com.dlabs.grants.admin.enums;

public enum Gender {
	MALE,
	FEMALE,
	OTHER
}
