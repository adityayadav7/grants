/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import com.dlabs.grants.admin.enums.ApplicantLanguage;
import com.dlabs.grants.admin.enums.MaritalStatus;
import com.dlabs.grants.admin.enums.Occupation;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class BasicInfo implements Serializable{
	
	private static final long serialVersionUID = -730763989631133322L;

	/*
	 *  Mobile Number used to login on behalf of teh applicant. may be same as applicant's mobile number
	 */
	@JsonProperty("facilitatorMobile")
	private String facilitatorMobile;
	
	/*
	 * First name of the applicant
	 */
	@JsonProperty("firstName")
	private String firstName;
	
	/*
	 * Middle name of the applicant
	 */
	@JsonProperty("middleName")
	private String middleName;
	
	/*
	 * Last name of the applicant
	 */
	@JsonProperty("lastName")
	private String lastName;
	
	
	/*
	 * Applicant's mobile Number
	 */
	@JsonProperty("applicantMobile")
	private String applicantMobile;
	
	/*
	 * Applicant's Email Address
	 */
	@JsonProperty("email")
	private String email;
	
	/*
	 * Age of the applicant
	 */
	@JsonProperty("age")
	private Integer age;
	
	@JsonProperty("dateOfBirth")
	@JsonFormat(pattern="dd-MM-yyyy")
	private LocalDate dateOfBirth;
	
	/*
	 * Martial status of the applicant
	 */
	@JsonProperty("education")
	private String education;
	
	/*
	 * Martial status of the applicant
	 */
	@JsonProperty("maritalStatus")
	private MaritalStatus maritalStatus;
	
	@JsonProperty("whatsAppNumber")
	private String whatsAppNumber;
	
	@JsonProperty("currentOccupation")
	private Occupation currentOccupation;
	
	@JsonProperty("otherCurrentOccupation")
	private String otherCurrentOccupation;
	
	@JsonProperty("languagePreference")
	private List<ApplicantLanguage> languagePreference;
	
	@JsonProperty("otherLanguage")
	private String otherLanguage;
	
	@JsonProperty("addressDetail")
	private AddressDetail addressDetail;
	
	@JsonProperty("currentLivingDetail")
	private CurrentLivingDetail currentLivingDetail;
	
	@JsonProperty("isPhysicallyChallenged")
	private String isPhysicallyChallenged;
	
	@JsonProperty("languagesKnown")
	private List<String> languagesKnown;
}

