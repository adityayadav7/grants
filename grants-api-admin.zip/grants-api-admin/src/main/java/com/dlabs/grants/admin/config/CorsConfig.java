package com.dlabs.grants.admin.config;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
class CorsConfig {
	
	@Bean
	public CorsFilter corsFilter() {
		
	    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    final CorsConfiguration config = new CorsConfiguration();
	    
	    config.setAllowCredentials(true);
	    
	    config.addAllowedOrigin("*");
	    
	    config.addAllowedHeader("*");
	    
	    config.addAllowedMethod("OPTIONS");
	    config.addAllowedMethod("GET");
	    config.addAllowedMethod("PUT");
	    config.addAllowedMethod("POST");
	    config.addAllowedMethod("DELETE");
	    
	    
	    List<String> allowedHeaders = new ArrayList<>();
	    allowedHeaders.add("Authorization");
	    allowedHeaders.add("x-xsrf-token");
	    allowedHeaders.add("Authorization");
	    allowedHeaders.add("Access-Control-Allow-Headers");
	    allowedHeaders.add("Origin");
	    allowedHeaders.add("Accept");
	    allowedHeaders.add("X-Requested-With");
	    allowedHeaders.add("Content-Type");
	    allowedHeaders.add("Access-Control-Request-Method");
	    allowedHeaders.add("Access-Control-Request-Headers");
	    allowedHeaders.add("X-Frame-Options");
	    allowedHeaders.add("Access-Control-Allow-Origin");
	    allowedHeaders.add("Access-Control-Allow-Credentials");
	    allowedHeaders.add("Access-Control-Allow-Methods");
	    
	    config.setAllowedHeaders(allowedHeaders);
	    config.setMaxAge(Duration.ofSeconds(3600));
	    source.registerCorsConfiguration("/**", config);
	    
	    return new CorsFilter(source);
	}

}
