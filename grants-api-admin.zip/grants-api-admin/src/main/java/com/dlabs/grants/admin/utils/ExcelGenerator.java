package com.dlabs.grants.admin.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.dlabs.grants.admin.model.Applicant;
import com.dlabs.grants.admin.model.GrantApplication;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExcelGenerator {
	
  private ExcelGenerator() {
	  //no-op
  }
	  
  public static ByteArrayInputStream applicantsToExcel(List<Applicant> applicants) throws IOException {
    log.trace("Inside applicantsToExcel... Applicant List Size [{}] ",applicants.size());
	String[] COLUMNs = {"Aadhar Number", "Name", "Contact Number","Education", "Age", "Marital Status","Family Members","Submitted By","Status","Approved Amount","Approved By"};
    try(
        Workbook workbook = new XSSFWorkbook();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
    ){
      CreationHelper createHelper = workbook.getCreationHelper();
   
      Sheet sheet = workbook.createSheet("Applicants");
   
      Font headerFont = workbook.createFont();
      headerFont.setBold(true);
      headerFont.setColor(IndexedColors.BLUE.getIndex());
   
      CellStyle headerCellStyle = workbook.createCellStyle();
      headerCellStyle.setFont(headerFont);
   
      // Row for Header
      Row headerRow = sheet.createRow(0);
   
      // Header
      for (int col = 0; col < COLUMNs.length; col++) {
        Cell cell = headerRow.createCell(col);
        cell.setCellValue(COLUMNs[col]);
        cell.setCellStyle(headerCellStyle);
      }
   
      // CellStyle for Age
      CellStyle ageCellStyle = workbook.createCellStyle();
      ageCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("#"));
   
      int rowIdx = 1;
      for (Applicant applicant : applicants) {
    	  List<GrantApplication> grantApplications = applicant.getGrantApplications();
    	  for (GrantApplication grantApplication : grantApplications) {
    		  Row row = sheet.createRow(rowIdx++);
    		  row.createCell(0).setCellValue(applicant.getAadharNumber());
    	        row.createCell(1).setCellValue(grantApplication.getBasicInfo().getFirstName()+" "+grantApplication.getBasicInfo().getLastName());
    	        row.createCell(2).setCellValue(grantApplication.getBasicInfo().getApplicantMobile());
    	        row.createCell(3).setCellValue(grantApplication.getBasicInfo().getEducation());
    	        
    	        Cell ageCell = row.createCell(4);
    	        ageCell.setCellValue(grantApplication.getBasicInfo().getAge());
    	        ageCell.setCellStyle(ageCellStyle);
    	        
    	        row.createCell(5).setCellValue(grantApplication.getBasicInfo().getMaritalStatus().toString());
    	        
				row.createCell(6)
						.setCellValue(grantApplication.getFamilyInfo().getFamilyMembers() == null ? String.valueOf(0)
								: String.valueOf(grantApplication.getFamilyInfo().getFamilyMembers().stream()
										.collect(Collectors.toList()).size()));
    	        row.createCell(7).setCellValue(String.valueOf(grantApplication.getBasicInfo().getFacilitatorMobile()));
    	        row.createCell(8).setCellValue(grantApplication.getApplicationStatus().toString().equalsIgnoreCase("CREATED") ? "PENDING" : grantApplication.getApplicationStatus().toString());
    	        row.createCell(9).setCellValue(grantApplication.getApprovedAmount());
    	        row.createCell(10).setCellValue(grantApplication.getApprovedBy());
    	  }
      }
      
      workbook.write(out);
      log.trace("excel doc generated and returned.. ");
      return new ByteArrayInputStream(out.toByteArray());
    }
  }
}