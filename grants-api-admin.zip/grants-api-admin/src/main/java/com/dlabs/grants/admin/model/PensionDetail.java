package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
@JsonInclude(Include.NON_NULL)
public class PensionDetail implements Serializable {

	private static final long serialVersionUID = 6962831053195677622L;
	
	@JsonProperty("isPensionable")
	private boolean isPensionable;
	
	@JsonProperty("details")
	private String details;
	
	@JsonProperty("fromScheme")
	private String fromScheme;
	
	@JsonProperty("fromHusband")
	private String fromHusband;
	
	@JsonProperty("fromOther")
	private String fromOther;
}
