/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.time.LocalDate;

import com.dlabs.grants.admin.constants.Constants;
import com.dlabs.grants.admin.dto.ApplicantDTO;
import com.dlabs.grants.admin.dto.ApplicationProcessRequest;
import com.dlabs.grants.admin.enums.ApplicationStatus;
import com.dlabs.grants.admin.enums.RequestStatus;
import com.dlabs.grants.admin.exception.ApplicantNotFoundException;
import com.dlabs.grants.admin.exception.DataNotAvailableToExportException;
import com.dlabs.grants.admin.exception.GrantApplicationNotFoundException;
import com.dlabs.grants.admin.exception.IncorrectRequestStatusException;
import com.dlabs.grants.admin.exception.RequestStatusNotFoundException;
import com.dlabs.grants.admin.model.Applicant;
import com.dlabs.grants.admin.model.GrantApplication;
import com.dlabs.grants.admin.repo.ApplicantRepository;
import com.dlabs.grants.admin.utils.ExcelGenerator;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AdminServiceImpl implements AdminService {

	@Autowired
	ApplicantRepository applicantRepo;

	@Override
	public List<ApplicantDTO> getApplications(RequestStatus requestStatus, Integer pageNumber, Integer pageSize) {
		
		log.debug("Get all Applications... applicationStatus[{}] ", requestStatus);
		
		if (requestStatus == null) {
			throw new RequestStatusNotFoundException(Constants.REQUEST_STATUS_NOT_FOUND);
		}

		if (requestStatus == RequestStatus.PENDING) {
			log.trace("getApplications : Where ApplicationStatus = CREATED ");
			List<ApplicationStatus> statuses = Arrays.asList(ApplicationStatus.CREATED);
			
			List<Applicant> createdApplicants = applicantRepo.getApplicationsByStatus(statuses, pageNumber, pageSize);
			
			List<ApplicantDTO> filteredApplicants = getFilteredApplicants(createdApplicants);
			log.debug("applicants returned : {} ",filteredApplicants.size());			
			return filteredApplicants;

		} else if (requestStatus == RequestStatus.PROCESSED) {
			log.trace("getApplications : Where ApplicationStatus = APPROVED/REJECTED ");
			List<ApplicationStatus> statuses = Arrays.asList(ApplicationStatus.APPROVED, ApplicationStatus.REJECTED);
			
			List<Applicant> processedApplicants = applicantRepo.getApplicationsByStatus(statuses, pageNumber, pageSize);
			
			List<ApplicantDTO> filteredApplicants = getFilteredApplicants(processedApplicants);
			log.debug("applicants returned : {} ",filteredApplicants.size());
			return filteredApplicants;
		} 
		else if(requestStatus == RequestStatus.SCHEDULED) {
			log.trace("getApplications : Where ApplicationStatus = APPROVED");
			List<ApplicationStatus> statuses = Arrays.asList(ApplicationStatus.APPROVED);
			
			List<Applicant> processedApplicants = applicantRepo.getApplicationsByStatus(statuses, pageNumber, pageSize);
			
			List<ApplicantDTO> filteredApplicants = getFilteredApplicants(processedApplicants);
			log.debug("applicants returned : {} ",filteredApplicants.size());
			return filteredApplicants;
			
		}
		else {
			log.trace("Incorrect request status...");
			throw new IncorrectRequestStatusException(Constants.INCORRECT_REQUEST_STATUS);
		}

	}
	
	private List<ApplicantDTO> getFilteredApplicants(List<Applicant> applicants) {
		log.trace("Inside getFilteredApplicants... ");
		List<ApplicantDTO> filteredApplicants = new ArrayList<>();
		applicants.stream().forEach(applicant -> {
			
			//Get last created/approved/rejected GrantApplication based on created time
			Optional<GrantApplication> grantApplicationOpt = applicant.getGrantApplications().stream()
					.sorted(Comparator.comparing(GrantApplication::getCreatedOn).reversed()).findFirst();

			if (grantApplicationOpt.isEmpty()) {
				throw new GrantApplicationNotFoundException(Constants.GRANT_APPLICANTION_NOT_FOUND);
			}
			GrantApplication grantApplication = grantApplicationOpt.get();
			log.debug("grantApplication : {} ", grantApplication);

			ApplicantDTO filteredApplicant = new ApplicantDTO();
			filteredApplicant.setAadharNumber(applicant.getAadharNumber());
			filteredApplicant.setApplicationNumber(grantApplication.getApplicationNumber());
			filteredApplicant.setFirstName(grantApplication.getBasicInfo().getFirstName());
			filteredApplicant.setLastName(grantApplication.getBasicInfo().getLastName());
			filteredApplicant.setApplicantMobile(grantApplication.getBasicInfo().getApplicantMobile());
			filteredApplicant.setFacilitatorMobile(grantApplication.getBasicInfo().getFacilitatorMobile());
			filteredApplicant.setState(grantApplication.getBasicInfo().getAddressDetail().getState());
			filteredApplicant.setCity(grantApplication.getBasicInfo().getAddressDetail().getCity());
			filteredApplicant.setApprovedAmount(grantApplication.getApprovedAmount());
			filteredApplicant.setApplicationStatus(grantApplication.getApplicationStatus());
			filteredApplicant.setCreatedOn(grantApplication.getCreatedOn());
			filteredApplicant.setPaymentStartDate(LocalDate.now());
			filteredApplicant.setNextPaymentDate(LocalDate.now());
			filteredApplicant.setExpiryDate(LocalDate.now());

			filteredApplicants.add(filteredApplicant);
		});
		log.trace("Exit getFilteredApplicants... ");
		return filteredApplicants;
	}
	
	@Override
	public ByteArrayInputStream excelApprovedApplicationsReport() throws IOException {

		log.debug("Inside excelApprovedApplicationsReport ");
		List<ApplicationStatus> statuses = Arrays.asList(ApplicationStatus.APPROVED);

		List<Applicant> applicantsWithApprovedApplications = applicantRepo.getApplicationsByStatus(statuses, null, null);

		if (applicantsWithApprovedApplications.isEmpty() || applicantsWithApprovedApplications == null) {
			throw new DataNotAvailableToExportException(Constants.APPLICANT_DATA_NOT_FOUND);
		}

		ByteArrayInputStream applicantsToExcel = ExcelGenerator.applicantsToExcel(applicantsWithApprovedApplications);
		return applicantsToExcel;
	}
	
	@Override
	public ByteArrayInputStream excelAllApplicationsReport() throws IOException {
		log.debug("Inside excelAllApplicationsReport ");
		List<ApplicationStatus> statuses = Arrays.asList(ApplicationStatus.APPROVED,ApplicationStatus.REJECTED,ApplicationStatus.CREATED);

		List<Applicant> applicantsWithApprovedApplications = applicantRepo.getApplicationsByStatus(statuses, null, null);

		if (applicantsWithApprovedApplications.isEmpty() || applicantsWithApprovedApplications == null) {
			throw new DataNotAvailableToExportException(Constants.APPLICANT_DATA_NOT_FOUND);
		}

		ByteArrayInputStream applicantsToExcel = ExcelGenerator.applicantsToExcel(applicantsWithApprovedApplications);
		return applicantsToExcel;
	}

	@Override
	public void processApplication(ApplicationProcessRequest applicationProcessRequest) {
		log.debug("processApplication... {} ", applicationProcessRequest);
		Optional<Applicant> existingApplicantOpt = applicantRepo.findById(applicationProcessRequest.getAadharNumber());

		if (existingApplicantOpt.isEmpty()) {
			throw new ApplicantNotFoundException(Constants.APPLICANT_DATA_NOT_FOUND);
		}

		Applicant existingApplicant = existingApplicantOpt.get();
		Optional<GrantApplication> matchedGrantApplication = existingApplicant.getGrantApplications().stream()
				.filter(grantApplication -> grantApplication.getApplicationNumber()
						.equals(applicationProcessRequest.getApplicationNumber()))
				.findFirst();

		if (matchedGrantApplication.isEmpty()) {
			throw new GrantApplicationNotFoundException(Constants.GRANT_APPLICANTION_NOT_FOUND + " application no. "
					+ applicationProcessRequest.getApplicationNumber());
		}
		if (applicationProcessRequest.getOperation() != null) {
			if (applicationProcessRequest.getOperation().equalsIgnoreCase("APPROVE")) {
				log.trace("performing approve operation...");
				if(applicationProcessRequest.getAdditionalDetails() != null) {
				matchedGrantApplication.get().setAdditionalDetails(applicationProcessRequest.getAdditionalDetails());
				}
				matchedGrantApplication.get().setApplicationStatus(ApplicationStatus.APPROVED);
				matchedGrantApplication.get().setApprovedAmount(applicationProcessRequest.getApprovedAmount());
				matchedGrantApplication.get().setApprovedBy(applicationProcessRequest.getApprovedBy());
			} else if (applicationProcessRequest.getOperation().equalsIgnoreCase("REJECT")) {
				log.trace("performing reject operation...");
				if(applicationProcessRequest.getAdditionalDetails() != null) {
				matchedGrantApplication.get().setAdditionalDetails(applicationProcessRequest.getAdditionalDetails());
				}
				matchedGrantApplication.get().setApprovedAmount(0.0);
				matchedGrantApplication.get().setApplicationStatus(ApplicationStatus.REJECTED);
			}
		} else {
			log.trace("operation value is not found... performing save operation.");
			if (applicationProcessRequest.getAdditionalDetails() != null) {
				matchedGrantApplication.get().setAdditionalDetails(applicationProcessRequest.getAdditionalDetails());
			}
		}
		log.debug("saving processed application...{} ", existingApplicant);
		applicantRepo.save(existingApplicant);
	}

	@Override
	public Applicant getApplicant(String aadharNumber,String applicationNo) {
		log.info("getApplication> aadharNumber[{}], applicationNo[{}] ", aadharNumber,applicationNo);
	
		Optional<Applicant> existingApplicantOpt = applicantRepo.findByAadharNumberAndApplicationNumber(aadharNumber,
				applicationNo);

		if (existingApplicantOpt.isEmpty()) {
			throw new ApplicantNotFoundException(Constants.APPLICANT_DATA_NOT_FOUND);
		}

		Applicant existingApplicant = existingApplicantOpt.get();

		//if (!CollectionUtils.isEmpty(existingApplicant.getGrantApplications())) {
		//	existingApplicant.getGrantApplications()
					//.removeIf(grantApplication -> !grantApplication.getApplicationNumber().equals(applicationNo));
		//}

		log.debug("existingApplicant retrieved : {} ", existingApplicant);

		return existingApplicant;
	}

}
