/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/

package com.dlabs.grants.admin.dto;

import java.io.InputStream;
import java.nio.file.Path;

import lombok.Data;

@Data
public class ContentFile {

	private InputStream fileContent;
	private String fileContentType;
	private String fileName;
	private Path filePath;
}
