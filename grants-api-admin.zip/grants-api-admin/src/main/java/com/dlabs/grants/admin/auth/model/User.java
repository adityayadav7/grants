package com.dlabs.grants.admin.auth.model;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.dlabs.grants.admin.enums.Roles;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Document(collection = "User")
public class User {
	
	@Id
	private String id;

	@JsonProperty("userName")
	@NotEmpty
	@NotBlank
	@Indexed(unique = true)
	private String username;
	
	@JsonProperty("password")
	private String password;
	
	@JsonProperty("role")
	private List<Roles> role;
	
	@JsonProperty("description")
	private String description;
	
	@JsonProperty("created")
	private LocalDateTime created;
	
	@JsonProperty("lastModified")
	private LocalDateTime lastModified;
}
