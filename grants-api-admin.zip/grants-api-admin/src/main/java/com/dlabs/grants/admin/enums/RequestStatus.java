package com.dlabs.grants.admin.enums;

public enum RequestStatus {

	PENDING, PROCESSED, SCHEDULED;
}
