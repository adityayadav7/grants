/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-admin
 *     grants-admin can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class DocumentDetail implements Serializable{

	private static final long serialVersionUID = -22129105647523817L;
	
	/*
	 * Path location of stored photo
	 */
	@JsonProperty("uploadDecreeDivorce")
	private String uploadDecreeDivorce;
	
	@JsonProperty("uploadPhysicalChallenged")
	private String uploadPhysicalChallenged;
	
	@JsonProperty("uploadMedicalReport")
	private String uploadMedicalReport;
	
	@JsonProperty("uploadRentAgreement")
	private String uploadRentAgreement;
	
	@JsonProperty("uploadElectricityBill")
	private String uploadElectricityBill;
	
}