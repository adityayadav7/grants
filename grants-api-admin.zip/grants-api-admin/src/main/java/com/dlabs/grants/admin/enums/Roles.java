package com.dlabs.grants.admin.enums;
public enum Roles {

	ADMIN
}