package com.dlabs.grants.admin.notification.service.client;

import java.util.concurrent.Future;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dlabs.grants.admin.notification.model.SMSResponse;


@FeignClient(name="Kaleyra", url="${com.dlabs.notification-sms.api.provider.apiUrl}")
public interface SMSServiceClient {
	
	@RequestMapping(method = RequestMethod.GET, value = "/")
	Future<SMSResponse> sendMessage(@RequestParam("api_key") String apikey,
                                    @RequestParam("method") String method,
                                    @RequestParam("sender") String sender,
                                    @RequestParam("message") String message,
                                    @RequestParam("to") String numbers);

	@RequestMapping(method = RequestMethod.GET)
	Object checkCredits(@RequestParam("api_key") String apikey, 
								  @RequestParam("method") String method);
	
}
