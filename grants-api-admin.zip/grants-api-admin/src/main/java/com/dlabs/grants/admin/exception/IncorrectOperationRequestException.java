package com.dlabs.grants.admin.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class IncorrectOperationRequestException extends RuntimeException {

	private static final long serialVersionUID = 8023597003594538400L;

	public IncorrectOperationRequestException(String message) {
		super(message);
	}
}
