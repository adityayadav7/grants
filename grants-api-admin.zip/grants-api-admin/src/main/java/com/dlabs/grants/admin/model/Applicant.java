/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Document("Applicant")
@JsonInclude(Include.NON_NULL)
public class Applicant implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8593911752051296118L;


	/*
	 * Unique Id of the applicant. One Aadhar card can apply for grants multiple times
	 */
	@Id
	@JsonProperty("aadharNumber")
	private String aadharNumber;
	
	
	/*
	 * List of the grant applications of the applicant
	 */
	@JsonProperty("grantApplications")
	private List<GrantApplication> grantApplications;
	
	/*
	 * Applicant first registered on
	 */
	@CreatedDate
	@JsonFormat(pattern="dd-MM-yyyy HH:mm")
	LocalDateTime createdOn;
	
	/*
	 * applicant details updated on
	 */
	@LastModifiedDate
	@JsonFormat(pattern="dd-MM-yyyy HH:mm")
	LocalDateTime modifiedOn;
	
}

