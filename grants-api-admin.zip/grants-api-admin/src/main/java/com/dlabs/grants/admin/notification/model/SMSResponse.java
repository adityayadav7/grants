package com.dlabs.grants.admin.notification.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SMSResponse {


	@JsonProperty("status")
	private String status;
	
	@JsonProperty("message")
	private String message;
	
	@JsonProperty("data")
	private Data data;
	
	private class Data{
		
		@JsonProperty("id")
		private String id;
		
		@JsonProperty("customid")
		private String customid;
		
		@JsonProperty("customid1")
		private String customid1;
		
		@JsonProperty("customid2")
		private String customid2;
		
		@JsonProperty("mobile")
		private String mobile;
		
		@JsonProperty("status")
		private String status;
	}


}
