package com.dlabs.grants.admin.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class IncorrectRequestStatusException extends RuntimeException {
	
	private static final long serialVersionUID = -2103421209386718681L;

	public IncorrectRequestStatusException(String message) {
		super(message);
	}
}