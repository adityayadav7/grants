/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/

package com.dlabs.grants.admin.service;

import java.io.FileNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.constants.Constants;
import com.dlabs.grants.admin.dto.ContentFile;
import com.dlabs.grants.admin.service.client.GoogleCloudStorageClient;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FileCloudStorageServiceImpl implements FileCloudStorageService{
	
	@Autowired
	GoogleCloudStorageClient googleCloudStorageClient;
	
	@Value("${com.dlabs.grants.applicant.gcsProject}")
	private String gcsProject;

	@Value("${com.dlabs.grants.applicant.gcsFileBucket}")
	private String gcsFileBucket;

	@Override
	public ContentFile getFile(String fileId) throws Exception {
		log.debug("fileId :{} ",fileId);

		ContentFile contentFile = googleCloudStorageClient.downloadFile(gcsProject, gcsFileBucket, fileId);
		if(contentFile == null) {
			throw new FileNotFoundException(Constants.FILE_NOT_FOUND + fileId);
		}
		log.debug("returing matched file.... FileName[{}] ",contentFile.getFileName());
		return contentFile;
	}
}
