package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class AddressDetail implements Serializable{
	
	private static final long serialVersionUID = 5710938445765705868L;

	@JsonProperty("details")
	private String details;
	
	@JsonProperty("city")
	private String city;
	
	@JsonProperty("postOffice")
	private String postOffice;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("pincode")
	private String pincode;
	
	@JsonProperty("permanent")
	private String permanent;
}
