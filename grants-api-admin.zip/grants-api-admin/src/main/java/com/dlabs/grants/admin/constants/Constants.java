package com.dlabs.grants.admin.constants;

public class Constants {
	
	private Constants() {
		//no-op
	}
	
	public static final String CSV = "\\s*,\\s*";

	public static final String APPLICANT_DATA_NOT_FOUND = " Applicant(s) Data Not Found ";
	public static final String INCORRECT_REQUEST_STATUS = " Only allowed request status are PENDING and PROCESSED. "; 
	public static final String REQUEST_STATUS_NOT_FOUND = " Request Status not found. Allowed Status : PENDING and PROCESSED";
	public static final String GRANT_APPLICANTION_NOT_FOUND = "Grant application not found : ";
	public static final String INCORRECT_OPERATION_REQUEST = " Please provide correct operation value. Allowed Operation : [APPROVE/REJECT]  ";
	public static final String FILE_NOT_FOUND = "There is no file found for : ";
}
