/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;

import com.dlabs.grants.admin.enums.ApplicationStatus;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class GrantApplication implements Serializable{
	
	private static final long serialVersionUID = -5622235403503457011L;

	/*
	 * Auto generated Application number
	 */
	@Id
	@JsonProperty("applicationNumber")
	private String applicationNumber;
	
	/*
	 * Path location of stored photo
	 */
	@JsonProperty("applicantPhotoPath")
	private String applicantPhotoPath;
	
	
	/*
	 * Basic details of the applicant
	 */
	@JsonProperty("basicInfo")
	private BasicInfo basicInfo;
	
	/*
	 * Family details of the applicant
	 */
	@JsonProperty("familyInfo")
	private FamilyInfo familyInfo;
	
	/*
	 * Bank details of the applicant
	 */
	@JsonProperty("bankInfo")
	private BankInfo bankInfo;

	/*
	 * Approved amount
	 */
	@JsonProperty("approvedAmount")
	private double approvedAmount;
	
	/*
	 * Additional Details
	 */
	@JsonProperty("additionalDetails")
	private String additionalDetails;
	
	/*
	 * User who is approving
	 */
	@JsonProperty("approvedBy")
	private String approvedBy;
	
	/*
	 * Path location of stored photo
	 */
	@JsonProperty("aadharPhotoPath")
	private String aadharPhotoPath;
	
	/*
	 * Path location of stored photo
	 */
	@JsonProperty("additionalDocPath")
	private String additionalDocPath;

	/*
	 * Application status
	 */
	@JsonProperty("applicationStatus")
	private ApplicationStatus applicationStatus;
	
	/*
	 * Applicant first registered on
	 */
	@CreatedDate
	@JsonFormat(pattern="dd-MM-yyyy HH:mm")
	LocalDateTime createdOn;
	
	/*
	 * applicant details updated on
	 */
	@LastModifiedDate
	@JsonFormat(pattern="dd-MM-yyyy HH:mm")
	LocalDateTime modifiedOn;
	
	/*
	 * Path location of stored photo
	 */
	@JsonProperty("cancelledChequePhotoPath")
	private String cancelledChequePhotoPath;
	
	/*
	 * Document details of the applicant
	 */
	@JsonProperty("documentDetail")
	private DocumentDetail documentDetail;
	
	@JsonProperty("paymentStartDate")
	private String paymentStartDate;
	
}

