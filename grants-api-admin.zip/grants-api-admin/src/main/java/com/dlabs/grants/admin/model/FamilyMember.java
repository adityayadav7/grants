/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;


import java.io.Serializable;
import java.time.LocalDate;

import com.dlabs.grants.admin.enums.Gender;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FamilyMember implements Serializable{
	
	private static final long serialVersionUID = 5372522378469459308L;

	/*
	 *  Family member name
	 */
	@JsonProperty("memberName")
	private String memberName;
	
	/*
	 * Family member education
	 */
	@JsonProperty("eduction")
	private String eduction;
	
	/*
	 * Family member age
	 */
	@JsonProperty("memberAge")
	@JsonFormat(pattern="dd-MM-yyyy")
	private LocalDate memberAge;
	
	/*
	 * Family member age
	 */
	@JsonProperty("age")
	private Integer age;
	
	/*
	 * Relationship of this member with the applicant
	 */
	@JsonProperty("memberRelation")
	private String memberRelation;
	
	/*
	 * Family member Gender
	 */
	@JsonProperty("memberGender")
	private Gender memberGender;
	
	/*
	 * Is this member LivingWithYou
	 */
	@JsonProperty("isLivingWithYou")
	private boolean isLivingWithYou;
	
	/*
	 * Family member Contact
	 */
	@JsonProperty("memberContact")
	private String memberContact;
	
	@JsonProperty("isLivingWithYou1")
	private String isLivingWithYou1;
	
}

