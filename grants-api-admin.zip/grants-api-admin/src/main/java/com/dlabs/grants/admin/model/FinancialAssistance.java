package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
@JsonInclude(Include.NON_NULL)
public class FinancialAssistance implements Serializable {
	
	private static final long serialVersionUID = 6427106715711967423L;

	@JsonProperty("isPreviouslyReceived")
	private boolean isPreviouslyReceived;
	
	@JsonProperty("details")
	private String details;
	
	@JsonProperty("fromChildren")
	private String fromChildren;
	
	@JsonProperty("fromRelatives")
	private String fromRelatives;
	
	@JsonProperty("fromTrust")
	private String fromTrust;
	
	@JsonProperty("fromOther")
	private String fromOther;
}
