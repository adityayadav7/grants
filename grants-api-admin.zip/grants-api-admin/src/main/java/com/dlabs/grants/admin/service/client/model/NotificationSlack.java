package com.dlabs.grants.admin.service.client.model;

import com.dlabs.grants.admin.enums.AlertType;

import lombok.Data;

@Data
public class NotificationSlack {
	
	/*
	 * Notification Alert Type
	 */
	AlertType alertType;
	/*
	 * Title of the notification
	 */
	String title;
	/*
	 * Message
	 */
	String message;
	/*
	 * Slack Channel
	 */
	String channel;
}
