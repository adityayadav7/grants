/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-admin
 *     grants-admin can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/

package com.dlabs.grants.admin.repo.extn;

import java.util.List;
import java.util.Optional;

import com.dlabs.grants.admin.enums.ApplicationStatus;
import com.dlabs.grants.admin.model.Applicant;

public interface ManageApplicant {
	
	List<Applicant> getApplicationsByStatus(List<ApplicationStatus> statuses, Integer pageNumber, Integer pageSize);
	Optional<Applicant> findByAadharNumberAndApplicationNumber(String aadharNumber,String applicationNumber);
}
