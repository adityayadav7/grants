package com.dlabs.grants.admin.controller;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dlabs.grants.admin.dto.ContentFile;
import com.dlabs.grants.admin.service.FileCloudStorageService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class FileCloudStorageController {
	
	@Autowired
	FileCloudStorageService fileService;
	
	/***
	 * Get file
	 * @param fileId
	 * @throws Exception 
	 */
	@GetMapping(path="${com.dlabs.grants.admin.baseurl}"+"/file"+"${com.dlabs.grants.admin.baseurl.version}"+"/{fileId}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<byte[]> getFile(
			@PathVariable String fileId,
			HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		log.trace("Initiated get file");
	    ContentFile contentFile = fileService.getFile(fileId);
	    
	    /*
	    HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", contentFile.getFileContentType());
        headers.set("Content-Disposition", "inline; filename=\"" + contentFile.getFileName() + "\"");
        log.debug("Prepared headers....{}",headers.toString());
        ResponseEntity<byte[]> responseEntity = new ResponseEntity<byte[]>(contentFile.getFileContent().readAllBytes(), headers, HttpStatus.OK);
        */
       
        response.setContentType(contentFile.getFileContentType());
        response.addHeader("Content-Disposition","inline; filename=\"" + contentFile.getFileName() + "\"");
        return ResponseEntity.ok()
                .cacheControl(CacheControl.maxAge(86400, TimeUnit.SECONDS).cachePublic().noTransform().mustRevalidate())
                .body(contentFile.getFileContent().readAllBytes());
	}
}