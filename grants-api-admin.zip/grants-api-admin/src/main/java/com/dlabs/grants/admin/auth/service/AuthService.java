package com.dlabs.grants.admin.auth.service;

import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.auth.model.AuthToken;
import com.dlabs.grants.admin.auth.model.LoginUser;

@Service
public interface AuthService {

	AuthToken authenticate(LoginUser loginUser);
}
