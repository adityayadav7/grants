/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of notification-sms
 *     notification-sms can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.notification.model;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.dlabs.grants.admin.notification.enums.SenderType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SenderConfig {

	private String senderName;
	private String apiKey;

	@Value("${com.dlabs.notification-sms.api.provider.apiKey}")
	private String genericApiKey;

	@Value("${com.dlabs.notification-sms.api.provider.sender}")
	private String genericSenderName;

	@Value("${com.dlabs.notification-sms.api.provider.grants.apiKey}")
	private String grantsApiKey;

	@Value("${com.dlabs.notification-sms.api.provider.grants.sender}")
	private String grantsSenderName;

	@PostConstruct
	public void init() {
	}

	public void loadSenderConfig(SenderType senderType) {

		if (senderType != null && senderType.equals(SenderType.GRANTS)) {
			setSenderName(grantsSenderName);
			setApiKey(grantsApiKey);

		} else {
			log.trace("Generic Configs.");
			setSenderName(genericSenderName);
			setApiKey(genericApiKey);
		}

	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

}
