package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class FatherDetail implements Serializable{
	
	private static final long serialVersionUID = 3762256513739959399L;

	@JsonProperty("fatherName")
	private String fatherName;
	
	@JsonProperty("fatherAddress")
	private String fatherAddress;
	
	@JsonProperty("fatherMobile")
	private String fatherMobile;
}
