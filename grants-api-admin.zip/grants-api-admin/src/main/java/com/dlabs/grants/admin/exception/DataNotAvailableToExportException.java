package com.dlabs.grants.admin.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.NO_CONTENT)
public class DataNotAvailableToExportException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8047186741502506177L;

	public DataNotAvailableToExportException(String message) {
		super(message);
	}
}