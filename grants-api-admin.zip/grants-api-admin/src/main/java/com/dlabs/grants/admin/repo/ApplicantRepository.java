/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.repo;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.dlabs.grants.admin.model.Applicant;
import com.dlabs.grants.admin.repo.extn.ManageApplicant;

public interface ApplicantRepository extends MongoRepository<Applicant,String>, ManageApplicant{

	Optional<Applicant> findByAadharNumber(String aadharNumber);
}

