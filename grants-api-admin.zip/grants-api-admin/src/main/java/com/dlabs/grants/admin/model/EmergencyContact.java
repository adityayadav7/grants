/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-admin
 *     grants-admin can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class EmergencyContact implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8720985984449297822L;
	
	@JsonProperty("personName")
	private String personName;
	
	@JsonProperty("personMobile")
	private String personMobile;
	
	@JsonProperty("personRelationship")
	private String personRelationship;
	
	@JsonProperty("personAddress")
	private String personAddress;
	
}