package com.dlabs.grants.admin.notification.constants;

/***
 * This Constants Repository is for Message specific Strings such as <br>
 * logging messages, OTP messages, or some resuable long strings
 * @author 
 *
 */
public class MessageConstants {

	public static final String OTP_MESSAGE = "The OTP for logging on to DMart is ";
	
	public static final String INCORRECT_LENGTH = "Incorrect Length";
	
	public static final String PARAMETERS_TRACE = "Parameters received : "; 
		
	public static final String RETURNED_PARAM_TRACE = "Returning data : ";
	
	public static final String INVALID_MOBILE_NUMBER = "Mobile number is invalid, only 10 digit number is allowed and should start with any of 5,6,7,8,9 digit";
	
	public static final String INVALID_PIN_NUMBER = "PIN code provided is invalid";
	
	public static final String INVALID_EMAIL = "Invalid Email Address";
	
	public static final String INVALID_AADHAR = "Invalid Aadhar Number";
	
	public static final String INVALID_PAN = "Invalid PAN Number";
	
	public static final String INVALID_AGE = "Age Should be between 18 and 60";

}
