package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class BankDetail implements Serializable {
	
	private static final long serialVersionUID = 2005961374614460512L;
	
	/*
	 *  account number
	 */
	@JsonProperty("accountNumber")
	private String accountNumber;

	/*
	 * Account holder name
	 */
	@JsonProperty("accountHolderName")
	private String accountHolderName;
	
	
	/*
	 * Bank Name
	 */
	@JsonProperty("bankName")
	private String bankName;
	
	
	/*
	 * Branch Name
	 */
	@JsonProperty("branchName")
	private String branchName;
	
	
	/*
	 * Branch IFSC
	 */
	@JsonProperty("branchIFSC")
	private String branchIFSC;
	
	/*
	 * Bank Branch Address
	 */
	@JsonProperty("branchAddress")
	private String branchAddress;
	
	@JsonProperty("uploadCancelledCheque")
	private String uploadCancelledCheque;
	
	@JsonProperty("isJointAccount")
	private boolean isJointAccount;
	
	@JsonProperty("jointAccountHolderName")
	private String jointAccountHolderName;
	
	@JsonProperty("joinAccountHolderMobile")
	private String joinAccountHolderMobile;
	
	@JsonProperty("accountOperator")
	private String accountOperator;
	
	@JsonProperty("otherAccountOperatorName")
	private String otherAccountOperatorName;
	
	@JsonProperty("accountOperatorMobile")
	private String accountOperatorMobile;
}
