/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;


import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FamilyInfo implements Serializable{
	
	private static final long serialVersionUID = 8406287041774917001L;

	@JsonProperty("husbandDetail")
	private HusbandDetail husbandDetail;
	
	@JsonProperty("fatherDetail")
	private FatherDetail fatherDetail; 

	/*
	 * List of family members
	 */
	@JsonProperty("familyMembers")
	private List<FamilyMember> familyMembers;
	
	@JsonProperty("sourceOfIncome")
	private String sourceOfIncome;
	
	@JsonProperty("emergencyContact")
	private EmergencyContact emergencyContact;

}

