package com.dlabs.grants.admin.enums;

public enum HouseType {
	OWN, RENTAL
}
