package com.dlabs.grants.admin.dto;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class UserDto {

	@JsonProperty("userName")
	@NotEmpty
	@NotBlank
	private String username;
	
	@JsonProperty("password")
	private String password;
	
	@JsonProperty("role")
	private List<String> role;
	
	@JsonProperty("description")
	private String description;
	
}
