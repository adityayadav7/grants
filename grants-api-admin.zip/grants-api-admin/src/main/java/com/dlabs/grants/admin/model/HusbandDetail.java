package com.dlabs.grants.admin.model;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class HusbandDetail implements Serializable{

	private static final long serialVersionUID = 3325276860056891248L;

	@JsonProperty("husbandName")
	private String husbandName;
	
	@JsonProperty("husbandMobile")
	private String husbandMobile;
	
	@JsonProperty("dateOfDivorce")
	@JsonFormat(pattern="dd-MM-yyyy")
	private LocalDate dateOfDivorce;
	
	@JsonProperty("dateOfDeath")
	@JsonFormat(pattern="dd-MM-yyyy")
	private LocalDate dateOfDeath;
	
	/*
	 * Path location of stored photo
	 */
	@JsonProperty("uploadHusbandDeathCertificate")
	private String uploadHusbandDeathCertificate;
	
}
