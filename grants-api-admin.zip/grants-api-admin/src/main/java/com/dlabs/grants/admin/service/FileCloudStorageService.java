/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/

package com.dlabs.grants.admin.service;

import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.dto.ContentFile;

@Service
public interface FileCloudStorageService {

	ContentFile getFile(String fileId) throws Exception;
}
