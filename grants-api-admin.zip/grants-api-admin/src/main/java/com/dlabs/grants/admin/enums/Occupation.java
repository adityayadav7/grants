package com.dlabs.grants.admin.enums;
public enum Occupation {
	
	EMPLOYED,
	OWN_SMALL_BUSINESS,
	HOMEMAKER,
	UNEMPLOYED,
	OTHER
}
