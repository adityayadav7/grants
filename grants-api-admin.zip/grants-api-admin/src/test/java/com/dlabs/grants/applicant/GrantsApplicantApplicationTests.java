package com.dlabs.grants.applicant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrantsApplicantApplicationTests {

	@Test
	void contextLoads() {
	}

}
