/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-admin
 *     grants-admin can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/

package com.dlabs.grants.admin.repo.extn;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.dlabs.grants.admin.enums.ApplicationStatus;
import com.dlabs.grants.admin.exception.ApplicantNotFoundException;
import com.dlabs.grants.admin.model.Applicant;
import com.dlabs.grants.admin.model.GrantApplication;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ManageApplicantImpl implements ManageApplicant {

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public List<Applicant> getApplicationsByStatus(List<ApplicationStatus> statuses, Integer pageNumber, Integer pageSize) {

		log.trace("Inside getApplicationsByStatus... statuses= {} ",statuses.toString());
		/*
		 * Filter nested objects by using Aggregation queries. This will bring only selected nested objects basis teh criteria 
		 */
		List<AggregationOperation> operations = new ArrayList<AggregationOperation>();
		
		//Flatten the nested Array
		operations.add(Aggregation.unwind("grantApplications"));
		
		//Add Criteria
		operations.add(Aggregation
				.match(Criteria.where("grantApplications.applicationStatus").in(statuses)));
		
		//Sort the data
		operations.add(Aggregation.sort(Sort.Direction.ASC, "createdOn"));
		
		//Recreate the object as desired by pushing required data
		operations.add(Aggregation.group("aadharNumber")
				.push("createdOn").as("createdOn")
				.push("modifiedOn").as("modifiedOn")
				.push("grantApplications").as("grantApplications"));

		
		if (pageNumber != null && pageNumber != 0 && pageSize != null && pageSize != 0) {
			log.trace("pageNumber---{}--pageSize--{}", (pageNumber-1), pageSize);
			operations.add(Aggregation.skip((long)(pageNumber-1) * pageSize));
			operations.add(Aggregation.limit(pageSize));
		}
		
		TypedAggregation<Applicant> aggregationResult = Aggregation.newAggregation(Applicant.class, operations);
		
		List<Applicant> applicantWithFilteredApplications = mongoTemplate.aggregate(aggregationResult, Applicant.class, Applicant.class).getMappedResults();
		
		log.trace("returning applicants with filtered applications.... fetchedRecords : [{}] ",applicantWithFilteredApplications.size());
		
		return applicantWithFilteredApplications;
	}

	@Override
	public Optional<Applicant> findByAadharNumberAndApplicationNumber(String aadharNumber, String applicationNumber) {
		log.info("Inside findByAadharNumberAndApplicationNumber... aadharNumber = {}, applicationNumber = {} ",aadharNumber,applicationNumber);
		
		long startTime = System.currentTimeMillis();
		
		final Query aadharQuery = new Query();
		aadharQuery.addCriteria(Criteria.where("aadharNumber").is(aadharNumber));
		boolean exist = mongoTemplate.exists(aadharQuery, Applicant.class);
		
		if (!exist) {
			log.error("Error! Applicant Record Not Found. aadharNumber = {}",aadharNumber);
			throw new ApplicantNotFoundException("Applicant Record Not Found. aadharNumber = "+ aadharNumber);
		}
		
		final Query grantsApplicationQuery = new Query();
		grantsApplicationQuery.addCriteria(Criteria.where("grantApplications.applicationNumber").is(applicationNumber));
		//Applicant applicant = new Applicant();
		Applicant result = mongoTemplate.findOne(grantsApplicationQuery, Applicant.class);
		long endTime = System.currentTimeMillis();
		long processingTime = endTime - startTime;
		log.trace("Time taken to fetch records from DB {} ms", processingTime);
		log.debug("applicant record found = {}",result);
		return Optional.of(result);
	}

}