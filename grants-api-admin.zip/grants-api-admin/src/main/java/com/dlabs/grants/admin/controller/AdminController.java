package com.dlabs.grants.admin.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dlabs.grants.admin.dto.ApplicantDTO;
import com.dlabs.grants.admin.dto.ApplicationProcessRequest;
import com.dlabs.grants.admin.enums.RequestStatus;
import com.dlabs.grants.admin.model.Applicant;
import com.dlabs.grants.admin.service.AdminService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@RequestMapping(method = RequestMethod.GET,path = "${com.dlabs.grants.admin.baseurl}"+"${com.dlabs.grants.admin.baseurl.version}",produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<List<ApplicantDTO>> getApplications(@RequestParam(required = true, value = "status") RequestStatus applicationStatus,HttpServletRequest request, HttpServletResponse response,
			@RequestParam(required = false, value = "pageNumber") Integer pageNumber,
			@RequestParam(required = false, value = "pageSize") Integer pageSize)
	{
	log.trace("Get all applications");
		return new ResponseEntity<>(adminService.getApplications(applicationStatus, pageNumber, pageSize), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, path = "${com.dlabs.grants.admin.baseurl}" + "/application"
			+ "${com.dlabs.grants.admin.baseurl.version}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<Applicant> getApplicant(
			@RequestParam(required = true, value = "aadharNumber") String aadharNumber,
			@RequestParam(required = true, value = "applicationNo") String applicationNo, HttpServletRequest request,
			HttpServletResponse response) {
		log.trace("Get grantApplication initiated...");
		return new ResponseEntity<>(adminService.getApplicant(aadharNumber, applicationNo), HttpStatus.OK);
	}
	
	
	@GetMapping(path = "${com.dlabs.grants.admin.baseurl}"+"${com.dlabs.grants.admin.baseurl.version}"+"/download/approved")
    public ResponseEntity<InputStreamResource> excelApprovedApplicationsReport() throws IOException {
    log.trace("excelApprovedApplicationsReport initiated....");
	ByteArrayInputStream excelApprovedApplicationsReport = adminService.excelApprovedApplicationsReport();
	
	LocalDateTime now = LocalDateTime.now().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.of("Asia/Kolkata")).toLocalDateTime();
	
    HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=ApprovedApplicants_"+LocalDateTime.now().format(DateTimeFormatter.ISO_TIME).toString()+".xlsx");
    
     return ResponseEntity
                  .ok()
                  .headers(headers)
                  .body(new InputStreamResource(excelApprovedApplicationsReport));
    }
	
	@GetMapping(path = "${com.dlabs.grants.admin.baseurl}"+"${com.dlabs.grants.admin.baseurl.version}"+"/download/all")
    public ResponseEntity<InputStreamResource> excelAllApplicationsReport() throws IOException {
    log.trace("excelAllApplicationsReport initiated....");
    ByteArrayInputStream excelAllApplicationsReport = adminService.excelAllApplicationsReport();
    
    HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=AllApplicants.xlsx");
    
     return ResponseEntity
                  .ok()
                  .headers(headers)
                  .body(new InputStreamResource(excelAllApplicationsReport));
    }
	
	@RequestMapping(method = RequestMethod.PUT,path = "${com.dlabs.grants.admin.baseurl}"+"${com.dlabs.grants.admin.baseurl.version}",consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<HttpStatus> processApplication(@RequestBody ApplicationProcessRequest approveRequest){
		log.trace("processApplication initiated....");
		adminService.processApplication(approveRequest);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
