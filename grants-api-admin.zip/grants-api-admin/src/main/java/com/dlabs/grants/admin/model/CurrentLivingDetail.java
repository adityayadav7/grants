package com.dlabs.grants.admin.model;

import java.io.Serializable;

import com.dlabs.grants.admin.enums.HouseType;
import com.dlabs.grants.admin.enums.LivingWith;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class CurrentLivingDetail implements Serializable {

	private static final long serialVersionUID = -3766141187320895870L;
	
	@JsonProperty("withWhom")
	private LivingWith withWhom;
	
	@JsonProperty("isCurrentStayGte12Mnt")
	private boolean isCurrentStayGte12Mnt;
	
	@JsonProperty("previousStayLocation")
	private String previousStayLocation;
	
	@JsonProperty("previousStayMonths")
	private Integer previousStayMonths;
	
	@JsonProperty("typeOfHouse")
	private HouseType typeOfHouse;
	
	@JsonProperty("withWhomOther")
	private String withWhomOther;

}
