package com.dlabs.grants.admin.notification.exception;

import org.springframework.stereotype.Component;

import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FeignErrorDecoder implements ErrorDecoder{

	@Override
	public Exception decode(String methodKey, Response response) {
		
		switch (response.status()) {
		case 400:
            log.error("Status code " + response.status() + ", methodKey = " + methodKey);

		default:
            log.error("Status code " + response.status() + ", methodKey = " + methodKey);

            return new Exception(response.reason());
		}
	}
	

}
