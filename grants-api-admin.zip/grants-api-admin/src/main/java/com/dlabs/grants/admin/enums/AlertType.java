package com.dlabs.grants.admin.enums;

public enum AlertType {

	INFORMATION, EXCEPTION, WARNING
}