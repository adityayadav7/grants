package com.dlabs.grants.admin.auth.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.auth.model.User;
import com.dlabs.grants.admin.dto.UserDto;

/***
 * UserService
 * @author 
 *
 */
@Service
public interface UserService {

	/***
	 * Creates user
	 */
	public void createUser(UserDto user);
	
	/***
	 * Find By User name
	 * @param username
	 * @return
	 */
	User findByUsername(String username);
	
	public void initSetup();

	List<User> getUsers();
}
