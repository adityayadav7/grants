package com.dlabs.grants.admin.service.client;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.constants.Constants;
import com.dlabs.grants.admin.dto.ContentFile;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GoogleCloudStorageClient {
 
	 public ContentFile downloadFile(String projectId, String bucketName, String fileName) throws IOException {
		 
		 Storage storage = StorageOptions.newBuilder().setProjectId(projectId).build().getService();
	     Blob blob = storage.get(BlobId.of(bucketName, fileName));
	     if(blob == null) {
	    	 throw new FileNotFoundException(Constants.FILE_NOT_FOUND + fileName);
	     }
	     Path tempDir = Files.createTempDirectory("GCS-Files");
	     File file = new File(tempDir.toString() + "//" + fileName);
	     blob.downloadTo(file.toPath());
	     log.trace("Downloaded file " + fileName + " from bucket name " + bucketName+ " to " + file);
	     ContentFile contentFile = new ContentFile(); 
	     contentFile.setFileContentType(blob.getContentType());
		 contentFile.setFileContent(new FileInputStream(file));
		 contentFile.setFileName(fileName);
		 contentFile.setFilePath(tempDir);
	     return contentFile;
     }
	
}