package com.dlabs.grants.admin.notification.service;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.notification.enums.SenderType;

@Service
public interface NotificationService {
	
	/***
	 * Sends given message to numbers 
	 * @param message
	 * @param numbers
	 * @return
	 */
	public Future<Object> sendSMS(String message, String numbers, SenderType senderType) throws InterruptedException, ExecutionException;

	/***
	 * Check SMS Credits
	 */
	public String checkSMSCredits();
}
