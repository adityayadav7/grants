package com.dlabs.grants.admin.notification.service;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.enums.AlertType;
import com.dlabs.grants.admin.notification.constants.MessageConstants;
import com.dlabs.grants.admin.notification.enums.SenderType;
import com.dlabs.grants.admin.notification.exception.KaleyraSMSServiceException;
import com.dlabs.grants.admin.notification.model.SMSResponse;
import com.dlabs.grants.admin.notification.model.SenderConfig;
import com.dlabs.grants.admin.notification.service.client.SMSServiceClient;
import com.dlabs.grants.admin.service.client.NotificationSlackService;
import com.dlabs.grants.admin.service.client.model.NotificationSlack;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {

	@Value("${com.dlabs.notification-sms.api.provider.apiKey}")
	private String kaleyra_api_key;

	@Value("${com.dlabs.notification-sms.api.provider.sender}")
	private String kaleyra_sender;

	@Value("${spring.profiles.active}")
	private String profile;
	
	@Value("${spring.application.name}")
	private String appName;
	
	@Value("${com.dlabs.notification-slack.webhook.url}")
	private String slackChannel;
	
	@Value("${com.dlabs.grants.admin.slackmsg.enabled}")
	private String slackEnabled;
	
	@Value("${whitelistedPhoneNumbers}")
	private String whitelistedPhoneNumbers;
	
	@Value("${spring.profiles.active}")
	private String activeProfile;
	
	@Autowired
	private SMSServiceClient smsClient;
	
	@Autowired
	private SenderConfig senderConfig;

	@Autowired
	private NotificationSlackService notificationSlackService;
	
	@Override
	@Async
	public Future<Object> sendSMS(String message, String recipient, SenderType senderType) throws InterruptedException, ExecutionException {

		log.debug("Inside " + this.getClass().getName());

		log.debug(MessageConstants.PARAMETERS_TRACE + " Message : " + message + " Numbers: " + recipient + " Sender " + senderType);
		
		List<String> phoneNumbers = Arrays.asList(whitelistedPhoneNumbers.split(","));
		if (!activeProfile.equals("prod") && recipient != null && !phoneNumbers.contains(recipient.strip())) {
			log.debug("Recipient {}", recipient);
			log.debug("WhiteListed numbers {}", phoneNumbers);
			return null;
		}

		Future<SMSResponse> smsResponse = null;
		try {
			
			/*
			 * Load sender configurations basis the senderType. 
			 * Each senderType maps to an application which consumes this notification service to send SMS
			*/
			senderConfig.loadSenderConfig(senderType);
			
			log.debug("Sender Config for {} application - APIKey: {}, Sender: {}", senderType, senderConfig.getApiKey(), senderConfig.getSenderName());
			smsResponse = smsClient.sendMessage(senderConfig.getApiKey(), "sms", senderConfig.getSenderName(), message, recipient);

			log.trace("Kaleyra SMS Response {}", smsResponse);
			if (smsResponse.get().getStatus().equalsIgnoreCase("OK")) {
				return new AsyncResult<>(smsResponse);
			}
		} catch (Exception exception) {
			log.debug("Kaleyra exception  " + exception.getMessage());
		}
		return null;

	}
	
	@SuppressWarnings("deprecation")
	@Override
	public String checkSMSCredits() {

		log.info("Checking Kaleyra SMS Credits...");
		String credits = "";
		try {
			Object kaleyraGetCreditResponse = smsClient.checkCredits(kaleyra_api_key, "account.credits");
			Gson gson = new Gson();
			JsonParser jsonParser = new JsonParser();
			JsonObject jsonObject = jsonParser.parse(gson.toJson(kaleyraGetCreditResponse)).getAsJsonObject().getAsJsonObject("data");
			log.trace("Response {}", jsonObject);
			credits = jsonObject.get("credits").getAsString();
			log.trace("Credits left : " + credits);
			//TODO email can be send to admin for reminder
			if(Integer.parseInt(credits) < 1) {
				sendSlackAlert(new KaleyraSMSServiceException("No SMS credits left in kaleyra account."), HttpStatus.SERVICE_UNAVAILABLE);
			}
			else if(Integer.parseInt(credits) > 1 && Integer.parseInt(credits) < 10){
				sendSlackAlert(new KaleyraSMSServiceException(credits + " SMS credits left in kaleyra account."), HttpStatus.CHECKPOINT);
			}
			return credits;
		}
		catch(Exception e) {
			log.trace(e.getMessage());
		}
		return credits;
	}
	
	@Async
	private void sendSlackAlert(Exception exception, HttpStatus httpStatus) {
		
		if(Boolean.parseBoolean(slackEnabled)) {
			NotificationSlack notificationSlack = new NotificationSlack();
			notificationSlack.setAlertType(AlertType.WARNING);
			
			notificationSlack.setMessage(exception.getMessage());
			notificationSlack.setTitle(profile.toUpperCase() + "-" + appName + " | " 
					+ exception.getStackTrace()[0].getMethodName() + "-" + httpStatus);
			notificationSlack.setChannel(slackChannel);
			
			notificationSlackService.send(notificationSlack);
		}
		
	}


}
