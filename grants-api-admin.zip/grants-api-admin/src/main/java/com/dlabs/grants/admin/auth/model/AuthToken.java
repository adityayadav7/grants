package com.dlabs.grants.admin.auth.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AuthToken {
	
	@JsonProperty("token")
	@NotEmpty
	@NotBlank
    private String token;
	
	@JsonProperty("userName")
	@NotEmpty
	@NotBlank
    private String userName;
	
	public AuthToken(String token, String username) {
		this.token = token;
		this.userName = username;
	}
 
}
