package com.dlabs.grants.admin.constants;
public class JwtConstants {

	    public static final String TOKEN_PREFIX = "Bearer ";
	    public static final String HEADER_STRING = "Authorization";
    
}
