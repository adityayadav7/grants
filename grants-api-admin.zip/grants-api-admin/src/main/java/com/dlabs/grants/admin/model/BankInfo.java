/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class BankInfo implements Serializable{
	
	private static final long serialVersionUID = 4398472493770755048L;

	@JsonProperty("financialAssistance")
	private FinancialAssistance financialAssistance;
	
	@JsonProperty("pensionDetails")
	private PensionDetail pensionDetail;
	
	@JsonProperty("bankDetail")
	private BankDetail bankDetail;
	
	/*
	 * Path location of stored photo
	 */
	@JsonProperty("uploadBankPassbook")
	private String uploadBankPassbook;
	
	@JsonProperty("sourceOfIncome")
	private String sourceOfIncome;
	
	@JsonProperty("monthlyIncome")
	private String monthlyIncome;
	
	@JsonProperty("otherSourceOfIncome")
	private String otherSourceOfIncome;
	
}

