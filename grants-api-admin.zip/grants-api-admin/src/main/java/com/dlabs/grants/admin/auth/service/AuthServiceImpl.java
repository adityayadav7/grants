package com.dlabs.grants.admin.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.auth.model.AuthToken;
import com.dlabs.grants.admin.auth.model.LoginUser;
import com.dlabs.grants.admin.auth.model.User;
import com.dlabs.grants.admin.auth.util.JwtTokenUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthServiceImpl implements AuthService {

	@Autowired
	UserService userService;
	
	@Autowired
	JwtTokenUtil jwtTokenUtil;

	@Autowired
	AuthenticationManager authenticationManager;
	
	@Override
	public AuthToken authenticate(LoginUser loginUser){

		log.trace("Authenticating...");
		
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginUser.getUsername(), loginUser.getPassword()));
        final User user = userService.findByUsername(loginUser.getUsername());
        final String token = jwtTokenUtil.generateToken(user);
        final AuthToken authTokenResponse = new AuthToken(token, user.getUsername());
        return authTokenResponse;
	}

	

}
