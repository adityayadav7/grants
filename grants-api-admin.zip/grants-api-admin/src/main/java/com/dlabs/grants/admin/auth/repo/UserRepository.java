package com.dlabs.grants.admin.auth.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.dlabs.grants.admin.auth.model.User;

public interface UserRepository extends  MongoRepository<User, String>{

	User findByUsername(String username);
	
}
