/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.dto;


import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;

import com.dlabs.grants.admin.enums.ApplicationStatus;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class ApplicantDTO {
	
	/*
	 * Unique Id of the applicant. One Aadhar card can apply for grants multiple times
	 */
	@NotNull
	@JsonProperty("aadharNumber")
	private String aadharNumber;
	
	/*
	 * Auto generated Application number
	 */
	@JsonProperty("applicationNumber")
	private String applicationNumber;
	
	/*
	 * First name of the applicant
	 */
	@JsonProperty("firstName")
	private String firstName;
	
	/*
	 * Last name of the applicant
	 */
	@JsonProperty("lastName")
	private String lastName;
	
	/*
	 * Applicant's mobile Number
	 */
	@JsonProperty("applicantMobile")
	private String applicantMobile;
	
	/*
	 *  Mobile Number used to login on behalf of teh applicant. may be same as applicant's mobile number
	 */
	@JsonProperty("facilitatorMobile")
	private String facilitatorMobile;
	
	
	/*
	 * state
	 */
	@JsonProperty("state")
	private String state;
	
	/*
	 * city
	 */
	@JsonProperty("city")
	private String city;
	
	/*
	 * Approved amount
	 */
	@JsonProperty("approvedAmount")
	private double approvedAmount;
	
	/*
	 * Application status
	 */
	@JsonProperty("applicationStatus")
	private ApplicationStatus applicationStatus;
	
	/*
	 * Grant Applicantion Creation Date
	 */
	@CreatedDate
	@JsonFormat(pattern="dd-MM-yyyy HH:mm")
	LocalDateTime createdOn;
	
	/*
	 * Recurring Grant start Date
	 */
	@JsonProperty("paymentStartDate")
	@JsonFormat(pattern="dd-MM-yyyy")
	LocalDate paymentStartDate;
	
	/*
	 * Recurring Grant next Payment Date
	 */
	@JsonProperty("nextPaymentDate")
	@JsonFormat(pattern="dd-MM-yyyy")
	LocalDate nextPaymentDate;
	
	/*
	 * Recurring Grant expire Date
	 */
	@JsonProperty("expiryDate")
	@JsonFormat(pattern="dd-MM-yyyy")
	LocalDate expiryDate;
}

