package com.dlabs.grants.admin.enums;

public enum LivingWith {
	OWN_HOME,
	ALONE_SELF,
	SON,
	DAUGHTER,
	PARENTS,
	OTHER
}
