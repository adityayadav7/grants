package com.dlabs.grants.admin.auth.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.auth.model.User;
import com.dlabs.grants.admin.auth.repo.UserRepository;
import com.dlabs.grants.admin.dto.UserDto;
import com.dlabs.grants.admin.enums.Roles;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	@Value("${com.dlabs.grants.admin.auth.admin.username}")
	private String adminusername;
	
	@Value("${com.dlabs.grants.admin.auth.admin.password}")
	private String adminPass;
	
	@Value("${com.dlabs.grants.admin.auth.runPostConstructScript}")
	private String runPostConstructScript;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Override
	public void createUser(UserDto userdto){
		
		log.debug("Creating user ");
		
		User existingUser = findByUsername(userdto.getUsername());
		
		if(existingUser != null) {
			throw new DuplicateKeyException("User already present with username " + userdto.getUsername());
		}
		User user = new User();
		user.setUsername(userdto.getUsername());
		user.setPassword(bcryptEncoder.encode(userdto.getPassword()));
		if(userdto.getRole() != null && !userdto.getRole().isEmpty()) {
			List<Roles> roles = new ArrayList<>();
			userdto.getRole().stream().forEach(role->roles.add(Roles.valueOf(role)));
			user.setRole(roles);
		}
		user.setDescription(userdto.getDescription());
		user.setCreated(LocalDateTime.now());
		user.setLastModified(LocalDateTime.now());
		userRepository.save(user);
		
		log.debug("User created ");
		
	}

	@Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

	@Override
	@PostConstruct
	public void initSetup() {

		if(Boolean.parseBoolean(runPostConstructScript)) {
			try {
				UserDto user = new UserDto();
				user.setUsername(adminusername);
				user.setPassword(adminPass);
				
				user.setRole(List.of(Roles.ADMIN.toString()));
				createUser(user);
			}
			catch(Exception e) {
				log.trace(e.getMessage());
			}
		}
		
	}

	@Override
	public List<User> getUsers() {

		log.debug("Getting users ");
		
		final Query query = new Query();
	
		query.fields().exclude("password");
		
		List<User> users = mongoTemplate.find(query, User.class);

		Comparator<User> userLastModifiedDateComparator = Comparator.comparing(User::getLastModified).reversed();
		users.sort(userLastModifiedDateComparator);
		
		log.debug("Got users {}", users);
		
		return users;
	}
}

