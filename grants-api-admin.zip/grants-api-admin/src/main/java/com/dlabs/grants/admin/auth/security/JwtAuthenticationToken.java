package com.dlabs.grants.admin.auth.security;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

public class JwtAuthenticationToken extends AbstractAuthenticationToken {

	private static final long serialVersionUID = 605456624800316499L;

	private String userName;
	
	public JwtAuthenticationToken(Collection<? extends GrantedAuthority> authorities, String userName) {
		super(authorities);
		this.userName = userName;
	}

	@Override
	public Object getCredentials() {
		return null;
	}

	@Override
	public Object getPrincipal() {
		return this.userName;
	}
}
