package com.dlabs.grants.admin.enums;

public enum ApplicantLanguage {
	HINDI,
	ENGLISH,
	OTHER
}
