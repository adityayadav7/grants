package com.dlabs.grants.admin.service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.dlabs.grants.admin.service.client.model.NotificationSlack;

/**
 * Feign Call
 */
@Service
@FeignClient(name = "notification-slack", url = "${com.dlabs.notification-slack.server.host}")
public interface NotificationSlackService 
{
	
	@PostMapping(value = "notification-slack/send/v1", 
			     consumes = { MediaType.APPLICATION_JSON_VALUE }, 
			     produces = {MediaType.APPLICATION_JSON_VALUE})
	public String send(@RequestBody(required = true) NotificationSlack message);
	
}