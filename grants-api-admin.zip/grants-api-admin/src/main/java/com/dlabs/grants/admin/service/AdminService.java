/*********************************Copyright Notice*****************************
 *     
 *
 *	   DMart Labs
 *     Copyright (c) [2019-2029] Avenue Supermarts Ltd.
 *     
 *     This file is part of grants-applicant
 *     grants-applicant can not be copied and/or distributed without the express
 * 	   permission of Avenue Supermarts Ltd.
 *
 *     Unauthorized copying of this file, via any medium is strictly prohibited
 *     Proprietary and confidential
 *******************************************************************************/
package com.dlabs.grants.admin.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dlabs.grants.admin.dto.ApplicantDTO;
import com.dlabs.grants.admin.dto.ApplicationProcessRequest;
import com.dlabs.grants.admin.enums.RequestStatus;
import com.dlabs.grants.admin.model.Applicant;

@Service
public interface AdminService {
	
	/**
	 * Get all applicants for the applicants
	 * @return List of all the Applicants along with their applications
	 */
	public List<ApplicantDTO> getApplications(RequestStatus requestStatus, Integer pageNumber, Integer pageSize);

	public ByteArrayInputStream excelApprovedApplicationsReport() throws IOException;

	public void processApplication(ApplicationProcessRequest approveRequest);

	public Applicant getApplicant(String aadharNumber,String applicationNo);

	public ByteArrayInputStream excelAllApplicationsReport() throws IOException;
}

