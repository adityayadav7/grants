package com.dlabs.grants.admin.exception.model;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class APIExceptionResponse {

	/*
	 * Http Status Code
	 */
	@JsonProperty("status")
	private HttpStatus status;
	
	/*
	 * Exception Message
	 */
	@JsonProperty("message")
	private String message;
	
	/*
	 * Exception Type
	 */
	@JsonProperty("type")
	private String type;
	
	public APIExceptionResponse(HttpStatus requestStatus, String message, String type) {
		
		this.status = requestStatus;
		this.message = message;
		this.type = type;
	}
}
