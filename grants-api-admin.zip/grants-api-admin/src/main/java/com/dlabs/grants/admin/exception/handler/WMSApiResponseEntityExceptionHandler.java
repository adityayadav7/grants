package com.dlabs.grants.admin.exception.handler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.dlabs.grants.admin.enums.AlertType;
import com.dlabs.grants.admin.exception.ApplicantNotFoundException;
import com.dlabs.grants.admin.exception.DataNotAvailableToExportException;
import com.dlabs.grants.admin.exception.ExpiredJwtTokenException;
import com.dlabs.grants.admin.exception.GrantApplicationNotFoundException;
import com.dlabs.grants.admin.exception.IncorrectOperationRequestException;
import com.dlabs.grants.admin.exception.IncorrectRequestStatusException;
import com.dlabs.grants.admin.exception.InvalidJWTAuthTokenException;
import com.dlabs.grants.admin.exception.RequestStatusNotFoundException;
import com.dlabs.grants.admin.exception.UserDetailsNotFoundException;
import com.dlabs.grants.admin.exception.model.APIExceptionResponse;
import com.dlabs.grants.admin.service.client.NotificationSlackService;
import com.dlabs.grants.admin.service.client.model.NotificationSlack;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class WMSApiResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	@Value("${com.dlabs.grants.admin.slackmsg.appName}")
	private String appName;

	@Value("${com.dlabs.notification-slack.webhook.url}")
	private String slackChannel;

	@Value("${spring.profiles.active}")
	private String profile;

	@Value("${com.dlabs.grants.admin.slackmsg.enabled}")
	private String slackEnabled;

	@Value("${com.dlabs.grants.admin.basePackage}")
	private String basePackage;

	@Autowired
	private NotificationSlackService notificationSlackService;

	@ExceptionHandler({ RequestStatusNotFoundException.class, ApplicantNotFoundException.class,
			GrantApplicationNotFoundException.class })
	public ResponseEntity<APIExceptionResponse> handleCustomExceptions(Exception exception, WebRequest request) {

		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.NOT_FOUND,
				exception.getMessage(), exception.getClass().getSimpleName());

		log.trace("Exit handleCustomExceptions exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(exception, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@ExceptionHandler({ DataNotAvailableToExportException.class })
	public ResponseEntity<APIExceptionResponse> dataNotAvailableToExportExceptions(Exception exception,
			WebRequest request) {

		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.NO_CONTENT,
				exception.getMessage(), exception.getClass().getSimpleName());

		log.trace("Exit handleCustomExceptions exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(exception, HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@ExceptionHandler({ IncorrectRequestStatusException.class, IncorrectOperationRequestException.class })
	public ResponseEntity<APIExceptionResponse> handleWrongRequestParamException(Exception exception,
			WebRequest request) {

		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.BAD_REQUEST,
				exception.getMessage(), exception.getClass().getSimpleName());

		log.trace("Exit handleCustomExceptions exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(exception, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@ExceptionHandler({ ExpiredJwtTokenException.class, InvalidJWTAuthTokenException.class,
			UserDetailsNotFoundException.class })
	public ResponseEntity<APIExceptionResponse> handleAuthExceptions(RuntimeException runtimeException,
			WebRequest request) {

		log.trace("Inside handleAuthExceptions exception handler");
		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.UNAUTHORIZED,
				runtimeException.getMessage(), runtimeException.getClass().getSimpleName());

		log.trace("Exit handleAuthExceptions exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(runtimeException, HttpStatus.UNAUTHORIZED);
		}

		log.trace("API Exception Response made : {}", apiExceptionResponse.toString());
		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@ExceptionHandler({ Exception.class })
	public ResponseEntity<APIExceptionResponse> handleExceptions(Exception exception, WebRequest request) {

		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.INTERNAL_SERVER_ERROR,
				exception.getMessage(), exception.getClass().getSimpleName());

		log.trace("Exit handleExceptions exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(exception, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@ExceptionHandler({ RuntimeException.class })
	public ResponseEntity<APIExceptionResponse> handleRuntimeException(RuntimeException runtimeException,
			WebRequest request) {

		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.INTERNAL_SERVER_ERROR,
				runtimeException.getMessage(), runtimeException.getClass().getSimpleName());

		log.trace("Exit handleRuntimeException exception handler");
		log.info("Exception {}", runtimeException);

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(runtimeException, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		log.trace("API Exception Response made : {}", apiExceptionResponse.toString());
		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@ExceptionHandler({ NullPointerException.class })
	public ResponseEntity<APIExceptionResponse> handleNullPointerException(NullPointerException nullPointerException,
			WebRequest request) {

		log.trace("Inside handleNullPointerException exception handler");
		String msg = nullPointerException.getMessage() == null || nullPointerException.getMessage().equals("null")
				? "Null values encounterd, refer logs for more details"
				: nullPointerException.getMessage();

		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.INTERNAL_SERVER_ERROR, msg,
				nullPointerException.getClass().getSimpleName());

		log.trace("Exit handleNullPointerException exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(nullPointerException, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException methodArgumentNotValidException, HttpHeaders headers, HttpStatus status,
			WebRequest request) {

		log.trace("Inside handleMethodArgumentNotValid exception handler");

		List<String> errDetails = new ArrayList<>();

		for (ObjectError error : methodArgumentNotValidException.getBindingResult().getAllErrors()) {
			errDetails.add(error.getDefaultMessage());
		}
		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.BAD_REQUEST,
				"Some of parameters are not valid, please check parameters such as : "
						+ methodArgumentNotValidException.getParameter().getParameterName(),
				methodArgumentNotValidException.getClass().getSimpleName());

		log.trace("Exit handleMethodArgumentNotValid exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(methodArgumentNotValidException, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(
			HttpMessageNotReadableException httpMessageNotReadableException, HttpHeaders headers, HttpStatus status,
			WebRequest request) {

		log.trace("Inside httpMessageNotReadableException exception handler");

		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(HttpStatus.BAD_REQUEST,
				"There is something wrong with paramters.", httpMessageNotReadableException.getClass().getSimpleName());

		log.trace("Exit httpMessageNotReadableException exception handler");

		if (Boolean.parseBoolean(slackEnabled)) {
			sendSlackAlert(httpMessageNotReadableException, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(apiExceptionResponse, apiExceptionResponse.getStatus());

	}

	@Async
	private void sendSlackAlert(Exception exception, HttpStatus status) {

		NotificationSlack notificationSlack = new NotificationSlack();
		notificationSlack.setAlertType(AlertType.EXCEPTION);

		notificationSlack.setMessage(getErrorMessage(exception));
		notificationSlack.setTitle(profile.toUpperCase() + "-" + appName + " | "
				+ exception.getStackTrace()[0].getMethodName() + "-" + status);
		notificationSlack.setChannel(slackChannel);

		notificationSlackService.send(notificationSlack);
	}

	private String getErrorMessage(Exception exception) {

		StringBuilder msg = new StringBuilder();
		msg.append("Exception type : " + exception.getClass().getSimpleName());
		msg.append("\n");
		if (exception instanceof NullPointerException)
			msg.append("Message : " + "Null value exception, refer logs or stack trace for more details.");
		else
			msg.append("Message : " + exception.getMessage());
		msg.append("\n");
		StackTraceElement[] elements = exception.getStackTrace();
		for (StackTraceElement element : elements) {
			if (element.getClassName().contains(basePackage)) {
				msg.append("From Line No " + element.getLineNumber() + " : " + element.getClassName() + "-"
						+ element.getMethodName());
				msg.append("\n");
			}
		}
		log.info(msg.toString());
		return msg.toString();
	}

}