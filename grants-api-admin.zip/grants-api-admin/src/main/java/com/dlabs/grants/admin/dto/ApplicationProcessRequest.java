package com.dlabs.grants.admin.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ApplicationProcessRequest {
	
	/*
	 * Unique Id of the applicant. One Aadhar card can apply for grants multiple times
	 */
	@NotEmpty
	@NotBlank
	@JsonProperty("aadharNumber")
	private String aadharNumber;
	
	/*
	 * Auto generated Application number
	 */
	@NotEmpty
	@NotBlank
	@JsonProperty("applicationNumber")
	private String applicationNumber;

	/*
	 * Additional Details
	 */
	@JsonProperty("additionalDetails")
	private String additionalDetails;
	
	/*
	 * Approved Amount
	 */
	@JsonProperty("approvedAmount")
	private double approvedAmount;
	
	/*
	 * User who is approving
	 */
	@JsonProperty("approvedBy")
	private String approvedBy;
	
	/*
	 * Operation Flag : Approve/Reject
	 */
	@NotEmpty
	@NotBlank
	@JsonProperty("operation")
	private String operation;
	
}
