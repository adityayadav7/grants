package com.dlabs.grants.admin.auth.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.filter.OncePerRequestFilter;

import com.dlabs.grants.admin.auth.util.JwtTokenUtil;
import com.dlabs.grants.admin.constants.Constants;
import com.dlabs.grants.admin.constants.JwtConstants;
import com.dlabs.grants.admin.enums.AlertType;
import com.dlabs.grants.admin.exception.ExpiredJwtTokenException;
import com.dlabs.grants.admin.exception.InvalidJWTAuthTokenException;
import com.dlabs.grants.admin.exception.UserDetailsNotFoundException;
import com.dlabs.grants.admin.exception.model.APIExceptionResponse;
import com.dlabs.grants.admin.service.client.NotificationSlackService;
import com.dlabs.grants.admin.service.client.model.NotificationSlack;
import com.google.gson.Gson;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.SignatureException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private NotificationSlackService notificationSlackService;
	
	@Value("${com.dlabs.grants.admin.slackmsg.appName}")
	private String appName;
	
	@Value("${com.dlabs.notification-slack.webhook.url}")
	private String slackChannel;
	
	@Value("${spring.profiles.active}")
	private String profile;
	
	@Value("${com.dlabs.grants.admin.auth.urlsToSkipAuth}")
    private String urlsToSkip;
	
	@Value("${com.dlabs.grants.admin.auth.loginUrl}")
	private String loginURL;
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		// 1. Get the token header
		String requestURL = request.getRequestURI();
		String requestMethod = request.getMethod();
		log.trace("Inside JwtAuthenticationFilter filter..{}", requestURL);
		
		if(!(exemptUrlExist(requestURL) && requestMethod.equals(HttpMethod.GET.toString())) && !requestURL.contains(loginURL)) {
			log.trace("Verifying request headers.....");

			String header = request.getHeader(JwtConstants.HEADER_STRING);
			String username = null;
			String authToken = null;

			try {
				// 2. Get the bearer token if it exists
				if (header != null && header.startsWith(JwtConstants.TOKEN_PREFIX)) {

					log.trace("Header found for JWT token.....");
					
					authToken = header.replace(JwtConstants.TOKEN_PREFIX, "");
				
				// 3. Check for username from token
					username = jwtTokenUtil.getUsernameFromToken(authToken);
					
				}else {
					log.trace("Couldn't find Bearer token");
					throw new AccessDeniedException("Couldn't find Bearer token");
				}

				if (username != null) {
					
					log.trace("Username found from JWT token.....");
					log.trace("Verifying user details.....");

					UserDetails userDetails = null;

					log.trace("Validating token.....");
					// 4. Check for user details from username if exist in db
					userDetails = userDetailsService.loadUserByUsername(username);
					// 5. Validate token 
					validateAuthToken(authToken, username, userDetails, true);
					
			
				}else {
					log.trace("Couldn't find username from authtoken");
					throw new AccessDeniedException("Couldn't find username from authtoken");
				}
			} catch (IllegalArgumentException exception) {
				log.error("An error occured during getting username from token");
				log.error(exception.getMessage());
				response = prepareResponse(response, "Method has been passed with an illegal or inappropriate argument.", false, HttpStatus.UNAUTHORIZED, exception);
				return;
			} catch (ExpiredJwtTokenException exception) {
				log.trace("The token is expired and not valid anymore", exception);
				log.error(exception.getMessage());
				response = prepareResponse(response, "The token is expired and not valid anymore.", false, HttpStatus.UNAUTHORIZED, exception);
				return;
			} catch (SignatureException exception) {
				log.error("Authentication Failed. Username or Password not valid.");
				log.error(exception.getMessage());
				response = prepareResponse(response, "Authentication failed, as signature in not valid.Either username or password is not correct.", false, HttpStatus.UNAUTHORIZED, exception);
				return;
			} catch (UsernameNotFoundException usernameNotFoundException) {
				log.error("Authentication Failed. Username not valid.");
				log.error(usernameNotFoundException.getMessage());
				response = prepareResponse(response, "Username " + usernameNotFoundException.getMessage() + " not found", false, HttpStatus.UNAUTHORIZED, usernameNotFoundException);
				return;
			} catch (RuntimeException runtimeException) {
				log.error(runtimeException.getMessage());
				response = prepareResponse(response, runtimeException.getMessage(), true, HttpStatus.UNAUTHORIZED, runtimeException);
				return;
			} catch (Exception exception) {
				log.error(exception.getMessage());
				response = prepareResponse(response, exception.getMessage(), true, HttpStatus.UNAUTHORIZED, exception);
				return;
			} 
		}
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Credentials", "true");
		response.setHeader("Access-Control-Allow-Methods", "POST, PUT, GET, OPTIONS, DELETE");
		//response.setHeader("X-Frame-Options", "ALLOW-FROM http://3e5d415e.ngrok.io/");
		// response.setHeader("Access-Control-Max-Age", "7200");
		response.setHeader("Access-Control-Allow-Headers",
				        "Authorization, x-xsrf-token, Access-Control-Allow-Headers, Origin, " + "Accept, X-Requested-With, "
						+ "Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, X-Frame-Options, "
						+ "Access-Control-Allow-Origin, Access-Control-Allow-Credentials, Access-Control-Allow-Methods");
		
		chain.doFilter(request, response);
	}

	private Boolean exemptUrlExist(String requestURL) {

		List<String> exemptUrls = Arrays.asList(urlsToSkip.split(Constants.CSV));
		for(int offset=0;offset < exemptUrls.size();offset++) {
			if(requestURL.contains(exemptUrls.get(offset).replace("/*", ""))) {
				return true;
			}
		}
		return false;
	}

	private void validateAuthToken(String authToken, String userName, UserDetails userDetails, boolean dbUser) throws UserDetailsNotFoundException, 
			InvalidJWTAuthTokenException {

		// 1. Check if expired
		if (jwtTokenUtil.isTokenExpired(authToken)) {

			log.trace("Checking token expiry.....");
			throw new ExpiredJwtTokenException("Jwt auth token is expired");
		}

		// 2. Check whether user is present in system
		if (userDetails == null && dbUser) {

			throw new UserDetailsNotFoundException("User details not found from jwt auth token");
		}
		
		// 3. Check whether token is valid for user details
		if (jwtTokenUtil.validateToken(authToken, userDetails)) {

			log.trace("Valid token.....");

			// 4. Get all meta from token as claims
			Claims claims = jwtTokenUtil.getAllClaimsFromToken(authToken);

			// 5. Get roles from token
			@SuppressWarnings("unchecked")
			ArrayList<LinkedHashMap<String, String>> roles = (ArrayList<LinkedHashMap<String, String>>) claims
					.get("roles");

			List<SimpleGrantedAuthority> auths = new ArrayList<>();

			roles.stream().filter(Objects::nonNull).forEach(role -> {
				role.entrySet().stream().forEach(entry->{
					String r = entry.getValue();
					auths.add(new SimpleGrantedAuthority(r));
				});
			});

			if(userDetails != null)
				userName = userDetails.getUsername();

			if(!userName.isEmpty()) {
				// 6. Set role in token
				JwtAuthenticationToken jAuthToken = new JwtAuthenticationToken(auths, userName);
				jAuthToken.setAuthenticated(true);
				log.trace("authenticated user " + userName + ", setting security context");
				
				// 7. Set auth token in security context
				SecurityContextHolder.getContext().setAuthentication(jAuthToken);
				log.trace("Authenticated token.....");
			}
			
		}
		else {
			
			throw new InvalidJWTAuthTokenException("JWT auth is not valid as user details not matched.");
		}
	}
	
	private HttpServletResponse prepareResponse(HttpServletResponse response, String body, boolean sendSlackAlert, HttpStatus httpStatus, Object object) throws IOException {
		
		APIExceptionResponse apiExceptionResponse = new APIExceptionResponse(httpStatus, 
				body, object.getClass().getSimpleName()); 
		response.setStatus(httpStatus.value());
		response.getWriter().write(new Gson().toJson(apiExceptionResponse));
		response.addHeader("Content-Type", "application/json");
		
		NotificationSlack notificationSlack = new NotificationSlack();
		notificationSlack.setAlertType(AlertType.EXCEPTION);
		notificationSlack.setChannel(slackChannel);
		notificationSlack.setMessage(body);
		notificationSlack.setTitle(profile.toUpperCase() + "-" + appName + " | " 
				+ "Authentication-Filter" + "-" + httpStatus);
		if(sendSlackAlert) {
			Runnable runnableSlackAlertTask = () -> { notificationSlackService.send(notificationSlack); };
			new Thread(runnableSlackAlertTask).start();
		}
		return response;
		
	}
}