package com.dlabs.grants.admin.auth.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LoginUser {

	@JsonProperty("userName")
	@NotEmpty
	@NotBlank
	private String username;
	
	@JsonProperty("password")
	@NotEmpty
	@NotBlank
	private String password;
	
}
