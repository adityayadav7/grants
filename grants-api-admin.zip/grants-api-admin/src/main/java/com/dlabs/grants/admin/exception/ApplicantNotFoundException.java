package com.dlabs.grants.admin.exception;

import org.springframework.web.bind.annotation.ResponseStatus;

import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ApplicantNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -8438044157029694744L;

	public ApplicantNotFoundException(String message) {
		super(message);
	}
}